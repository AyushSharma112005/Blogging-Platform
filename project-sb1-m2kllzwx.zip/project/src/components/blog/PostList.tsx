import React, { useState, useEffect } from 'react';
import { Search, Filter, Grid2x2 as Grid, List } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { Post, Category, Tag } from '../../types/database';
import PostCard from './PostCard';

interface PostListProps {
  authorId?: string;
  categorySlug?: string;
  tagSlug?: string;
  searchQuery?: string;
  showSearch?: boolean;
  showFilters?: boolean;
}

const PostList: React.FC<PostListProps> = ({
  authorId,
  categorySlug,
  tagSlug,
  searchQuery: initialSearchQuery = '',
  showSearch = true,
  showFilters = true,
}) => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState(initialSearchQuery);
  const [selectedCategory, setSelectedCategory] = useState(categorySlug || '');
  const [selectedTag, setSelectedTag] = useState(tagSlug || '');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState<'latest' | 'popular' | 'oldest'>('latest');

  useEffect(() => {
    fetchPosts();
    if (showFilters) {
      fetchCategories();
      fetchTags();
    }
  }, [authorId, categorySlug, tagSlug, searchQuery, selectedCategory, selectedTag, sortBy]);

  useEffect(() => {
    setSearchQuery(initialSearchQuery);
  }, [initialSearchQuery]);

  const fetchPosts = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('posts')
        .select(`
          *,
          profiles (
            username,
            full_name,
            avatar_url
          ),
          categories (
            id,
            name,
            slug,
            color
          )
        `)
        .eq('status', 'published');

      // Apply filters
      if (authorId) {
        query = query.eq('author_id', authorId);
      }

      if (selectedCategory || categorySlug) {
        const category = categories.find(c => c.slug === (selectedCategory || categorySlug));
        if (category) {
          query = query.eq('category_id', category.id);
        }
      }

      if (selectedTag || tagSlug) {
        const tag = tags.find(t => t.slug === (selectedTag || tagSlug));
        if (tag) {
          query = query.contains('tags', [{ id: tag.id }]);
        }
      }

      if (searchQuery) {
        query = query.or(`title.ilike.%${searchQuery}%,excerpt.ilike.%${searchQuery}%`);
      }

      // Apply sorting
      switch (sortBy) {
        case 'popular':
          query = query.order('view_count', { ascending: false });
          break;
        case 'oldest':
          query = query.order('published_at', { ascending: true });
          break;
        default:
          query = query.order('published_at', { ascending: false });
      }

      const { data, error } = await query.limit(20);

      if (error) throw error;

      // Fetch additional data for each post
      const postsWithStats = await Promise.all(
        (data || []).map(async (post) => {
          // Get tags
          const { data: postTags } = await supabase
            .from('post_tags')
            .select(`
              tags (
                id,
                name,
                slug
              )
            `)
            .eq('post_id', post.id);

          // Get likes count
          const { count: likesCount } = await supabase
            .from('likes')
            .select('id', { count: 'exact' })
            .eq('post_id', post.id);

          // Get comments count
          const { count: commentsCount } = await supabase
            .from('comments')
            .select('id', { count: 'exact' })
            .eq('post_id', post.id);

          return {
            ...post,
            tags: postTags?.map(pt => pt.tags).filter(Boolean) || [],
            likes_count: likesCount || 0,
            comments_count: commentsCount || 0,
          };
        })
      );

      setPosts(postsWithStats);
    } catch (error) {
      console.error('Error fetching posts:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    const { data } = await supabase
      .from('categories')
      .select('*')
      .order('name');
    if (data) setCategories(data);
  };

  const fetchTags = async () => {
    const { data } = await supabase
      .from('tags')
      .select('*')
      .order('name');
    if (data) setTags(data);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchPosts();
  };

  if (loading) {
    return (
      <div className="space-y-6">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="bg-white rounded-lg shadow-sm border p-6 animate-pulse">
            <div className="aspect-video bg-gray-200 rounded-lg mb-4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/4 mb-3"></div>
            <div className="h-6 bg-gray-200 rounded w-3/4 mb-3"></div>
            <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
            <div className="h-4 bg-gray-200 rounded w-2/3"></div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Search and Filters */}
      {(showSearch || showFilters) && (
        <div className="bg-white rounded-lg shadow-sm border p-6">
          {/* Search */}
          {showSearch && (
            <form onSubmit={handleSearch} className="mb-6">
              <div className="relative max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <input
                  type="text"
                  placeholder="Search posts..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                />
              </div>
            </form>
          )}

          {/* Filters */}
          {showFilters && (
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex flex-wrap items-center gap-4">
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                >
                  <option value="">All Categories</option>
                  {categories.map(category => (
                    <option key={category.id} value={category.slug}>
                      {category.name}
                    </option>
                  ))}
                </select>

                <select
                  value={selectedTag}
                  onChange={(e) => setSelectedTag(e.target.value)}
                  className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                >
                  <option value="">All Tags</option>
                  {tags.map(tag => (
                    <option key={tag.id} value={tag.slug}>
                      {tag.name}
                    </option>
                  ))}
                </select>

                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as 'latest' | 'popular' | 'oldest')}
                  className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                >
                  <option value="latest">Latest</option>
                  <option value="popular">Most Popular</option>
                  <option value="oldest">Oldest</option>
                </select>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 rounded-lg transition-colors ${
                    viewMode === 'grid' ? 'bg-indigo-100 text-indigo-600' : 'text-gray-400 hover:text-gray-600'
                  }`}
                >
                  <Grid className="h-4 w-4" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 rounded-lg transition-colors ${
                    viewMode === 'list' ? 'bg-indigo-100 text-indigo-600' : 'text-gray-400 hover:text-gray-600'
                  }`}
                >
                  <List className="h-4 w-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Posts Grid/List */}
      {posts.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">No posts found.</p>
        </div>
      ) : (
        <div className={
          viewMode === 'grid' 
            ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
            : 'space-y-6'
        }>
          {posts.map(post => (
            <PostCard
              key={post.id}
              post={post}
              className={viewMode === 'list' ? 'md:flex md:space-x-6' : ''}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default PostList;