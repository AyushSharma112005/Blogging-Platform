import React from 'react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { Heart, MessageCircle, Clock, Eye, User } from 'lucide-react';
import { Post } from '../../types/database';

interface PostCardProps {
  post: Post;
  showAuthor?: boolean;
  showStats?: boolean;
  className?: string;
}

const PostCard: React.FC<PostCardProps> = ({ 
  post, 
  showAuthor = true, 
  showStats = true,
  className = '' 
}) => {
  return (
    <article className={`bg-white rounded-lg shadow-sm border hover:shadow-md transition-shadow ${className}`}>
      {/* Cover Image */}
      {post.cover_image && (
        <div className="aspect-video relative overflow-hidden rounded-t-lg">
          <Link to={`/post/${post.slug}`}>
            <img
              src={post.cover_image}
              alt={post.title}
              className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
            />
          </Link>
          {post.featured && (
            <div className="absolute top-4 left-4">
              <span className="bg-yellow-500 text-white px-2 py-1 rounded-full text-xs font-medium">
                Featured
              </span>
            </div>
          )}
        </div>
      )}

      <div className="p-6">
        {/* Category */}
        {post.categories && (
          <div className="mb-3">
            <Link
              to={`/category/${post.categories.slug}`}
              className="inline-block px-2 py-1 text-xs font-medium rounded-full transition-colors"
              style={{
                backgroundColor: `${post.categories.color}20`,
                color: post.categories.color,
              }}
            >
              {post.categories.name}
            </Link>
          </div>
        )}

        {/* Title */}
        <h2 className="text-xl font-semibold text-gray-900 mb-3 line-clamp-2">
          <Link 
            to={`/post/${post.slug}`}
            className="hover:text-indigo-600 transition-colors"
          >
            {post.title}
          </Link>
        </h2>

        {/* Excerpt */}
        {post.excerpt && (
          <p className="text-gray-600 text-sm mb-4 line-clamp-2">
            {post.excerpt}
          </p>
        )}

        {/* Tags */}
        {post.tags && post.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {post.tags.slice(0, 3).map(tag => (
              <Link
                key={tag.id}
                to={`/tag/${tag.slug}`}
                className="text-xs text-gray-500 hover:text-indigo-600 transition-colors"
              >
                #{tag.name}
              </Link>
            ))}
            {post.tags.length > 3 && (
              <span className="text-xs text-gray-400">
                +{post.tags.length - 3} more
              </span>
            )}
          </div>
        )}

        {/* Author and Meta */}
        <div className="flex items-center justify-between text-sm text-gray-500">
          <div className="flex items-center space-x-4">
            {showAuthor && post.profiles && (
              <Link
                to={`/author/${post.profiles.username}`}
                className="flex items-center space-x-2 hover:text-gray-700 transition-colors"
              >
                {post.profiles.avatar_url ? (
                  <img
                    src={post.profiles.avatar_url}
                    alt={post.profiles.full_name || post.profiles.username}
                    className="w-6 h-6 rounded-full object-cover"
                  />
                ) : (
                  <User className="w-6 h-6 rounded-full bg-gray-200 p-1" />
                )}
                <span>{post.profiles.full_name || post.profiles.username}</span>
              </Link>
            )}

            <div className="flex items-center space-x-1">
              <Clock className="w-4 h-4" />
              <span>{post.reading_time} min read</span>
            </div>

            <time dateTime={post.published_at || post.created_at}>
              {format(new Date(post.published_at || post.created_at), 'MMM d')}
            </time>
          </div>

          {/* Stats */}
          {showStats && (
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-1">
                <Eye className="w-4 h-4" />
                <span>{post.view_count}</span>
              </div>
              
              {post.likes_count !== undefined && (
                <div className="flex items-center space-x-1">
                  <Heart className="w-4 h-4" />
                  <span>{post.likes_count}</span>
                </div>
              )}

              {post.comments_count !== undefined && (
                <div className="flex items-center space-x-1">
                  <MessageCircle className="w-4 h-4" />
                  <span>{post.comments_count}</span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </article>
  );
};

export default PostCard;