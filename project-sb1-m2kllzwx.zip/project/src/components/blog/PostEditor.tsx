import React, { useState, useRef, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { Image as ImageIcon, Save, Eye, X } from 'lucide-react';
import { supabase, createSlug, calculateReadingTime, uploadImage } from '../../lib/supabase';
import { useAuth } from '../../hooks/useAuth';
import { Post, Category, Tag } from '../../types/database';

interface PostEditorProps {
  post?: Post | null;
  onSave?: () => void;
  onCancel?: () => void;
}

const PostEditor: React.FC<PostEditorProps> = ({ post, onSave, onCancel }) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [title, setTitle] = useState(post?.title || '');
  const [content, setContent] = useState(post?.content || '');
  const [excerpt, setExcerpt] = useState(post?.excerpt || '');
  const [coverImage, setCoverImage] = useState(post?.cover_image || '');
  const [categoryId, setCategoryId] = useState(post?.category_id || '');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [status, setStatus] = useState<'draft' | 'published'>(post?.status as 'draft' | 'published' || 'draft');
  const [categories, setCategories] = useState<Category[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  const [newTag, setNewTag] = useState('');
  const [loading, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  React.useEffect(() => {
    fetchCategories();
    fetchTags();
    if (post) {
      fetchPostTags();
    }
  }, [post]);

  const fetchCategories = async () => {
    const { data } = await supabase
      .from('categories')
      .select('*')
      .order('name');
    if (data) setCategories(data);
  };

  const fetchTags = async () => {
    const { data } = await supabase
      .from('tags')
      .select('*')
      .order('name');
    if (data) setTags(data);
  };

  const fetchPostTags = async () => {
    if (!post) return;
    const { data } = await supabase
      .from('post_tags')
      .select('tag_id')
      .eq('post_id', post.id);
    if (data) {
      setSelectedTags(data.map(pt => pt.tag_id));
    }
  };

  const handleImageUpload = async (file: File) => {
    try {
      setUploading(true);
      const imageUrl = await uploadImage(file, 'blog-covers');
      setCoverImage(imageUrl);
    } catch (error) {
      console.error('Error uploading image:', error);
      alert('Failed to upload image');
    } finally {
      setUploading(false);
    }
  };

  const handleAddTag = async () => {
    if (!newTag.trim()) return;

    const slug = createSlug(newTag);
    const { data, error } = await supabase
      .from('tags')
      .insert({ name: newTag.trim(), slug })
      .select()
      .single();

    if (error && error.code !== '23505') {
      console.error('Error creating tag:', error);
      return;
    }

    if (data) {
      setTags([...tags, data]);
      setSelectedTags([...selectedTags, data.id]);
    } else {
      // Tag already exists, find it
      const { data: existingTag } = await supabase
        .from('tags')
        .select('*')
        .eq('slug', slug)
        .single();
      
      if (existingTag && !selectedTags.includes(existingTag.id)) {
        setSelectedTags([...selectedTags, existingTag.id]);
      }
    }

    setNewTag('');
  };

  const handleSave = async (saveStatus: 'draft' | 'published') => {
    if (!user || !title.trim() || !content.trim()) return;

    setSaving(true);
    try {
      const slug = createSlug(title);
      const readingTime = calculateReadingTime(content);
      const now = new Date().toISOString();

      const postData = {
        title: title.trim(),
        slug,
        excerpt: excerpt.trim(),
        content,
        cover_image: coverImage || null,
        category_id: categoryId || null,
        status: saveStatus,
        reading_time: readingTime,
        published_at: saveStatus === 'published' ? (post?.published_at || now) : null,
        updated_at: now,
      };

      let postId = post?.id;

      if (post) {
        // Update existing post
        const { error } = await supabase
          .from('posts')
          .update(postData)
          .eq('id', post.id);

        if (error) throw error;
      } else {
        // Create new post
        const { data, error } = await supabase
          .from('posts')
          .insert({
            ...postData,
            author_id: user.id,
          })
          .select()
          .single();

        if (error) throw error;
        postId = data.id;
      }

      // Update tags
      if (postId) {
        // Delete existing tags
        await supabase
          .from('post_tags')
          .delete()
          .eq('post_id', postId);

        // Insert new tags
        if (selectedTags.length > 0) {
          const postTags = selectedTags.map(tagId => ({
            post_id: postId,
            tag_id: tagId,
          }));

          await supabase
            .from('post_tags')
            .insert(postTags);
        }
      }

      if (onSave) {
        onSave();
      } else {
        navigate(saveStatus === 'published' ? `/post/${slug}` : '/dashboard');
      }
    } catch (error) {
      console.error('Error saving post:', error);
      alert('Failed to save post');
    } finally {
      setSaving(false);
    }
  };

  const modules = useMemo(() => ({
    toolbar: [
      [{ 'header': [1, 2, 3, false] }],
      ['bold', 'italic', 'underline', 'strike'],
      [{ 'list': 'ordered'}, { 'list': 'bullet' }],
      [{ 'script': 'sub'}, { 'script': 'super' }],
      [{ 'indent': '-1'}, { 'indent': '+1' }],
      ['blockquote', 'code-block'],
      [{ 'color': [] }, { 'background': [] }],
      [{ 'align': [] }],
      ['link', 'image'],
      ['clean']
    ]
  }), []);

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="bg-white rounded-lg shadow-sm border">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <h1 className="text-xl font-semibold text-gray-900">
            {post ? 'Edit Post' : 'Create New Post'}
          </h1>
          <div className="flex items-center space-x-3">
            <button
              onClick={() => handleSave('draft')}
              disabled={loading}
              className="flex items-center space-x-2 px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50"
            >
              <Save className="h-4 w-4" />
              <span>Save Draft</span>
            </button>
            <button
              onClick={() => handleSave('published')}
              disabled={loading}
              className="flex items-center space-x-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50"
            >
              <Eye className="h-4 w-4" />
              <span>Publish</span>
            </button>
            {onCancel && (
              <button
                onClick={onCancel}
                className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="h-5 w-5" />
              </button>
            )}
          </div>
        </div>

        {/* Form */}
        <div className="p-6 space-y-6">
          {/* Title */}
          <div>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter your post title..."
              className="w-full text-2xl font-bold placeholder-gray-400 border-0 focus:outline-none focus:ring-0 resize-none"
            />
          </div>

          {/* Excerpt */}
          <div>
            <textarea
              value={excerpt}
              onChange={(e) => setExcerpt(e.target.value)}
              placeholder="Write a brief excerpt (optional)..."
              rows={2}
              className="w-full text-gray-600 placeholder-gray-400 border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 resize-none"
            />
          </div>

          {/* Cover Image */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Cover Image
            </label>
            <div className="flex items-center space-x-4">
              {coverImage && (
                <div className="relative">
                  <img
                    src={coverImage}
                    alt="Cover"
                    className="w-32 h-20 object-cover rounded-lg"
                  />
                  <button
                    onClick={() => setCoverImage('')}
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 transition-colors"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleImageUpload(file);
                }}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50"
              >
                <ImageIcon className="h-4 w-4" />
                <span>{uploading ? 'Uploading...' : 'Upload Image'}</span>
              </button>
            </div>
          </div>

          {/* Category and Tags */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Category
              </label>
              <select
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="">Select a category</option>
                {categories.map(category => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Tags
              </label>
              <div className="space-y-2">
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    placeholder="Add a tag..."
                    className="flex-1 border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    onKeyPress={(e) => e.key === 'Enter' && handleAddTag()}
                  />
                  <button
                    type="button"
                    onClick={handleAddTag}
                    className="px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
                  >
                    Add
                  </button>
                </div>
                
                <div className="flex flex-wrap gap-2">
                  {selectedTags.map(tagId => {
                    const tag = tags.find(t => t.id === tagId);
                    return tag ? (
                      <span
                        key={tag.id}
                        className="inline-flex items-center px-2 py-1 bg-indigo-100 text-indigo-800 text-sm rounded-full"
                      >
                        {tag.name}
                        <button
                          onClick={() => setSelectedTags(selectedTags.filter(id => id !== tag.id))}
                          className="ml-1 text-indigo-600 hover:text-indigo-800"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </span>
                    ) : null;
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Content Editor */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Content
            </label>
            <div className="border border-gray-300 rounded-lg overflow-hidden">
              <ReactQuill
                theme="snow"
                value={content}
                onChange={setContent}
                modules={modules}
                placeholder="Start writing your post..."
                style={{ height: '400px' }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PostEditor;