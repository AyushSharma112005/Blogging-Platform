import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { TrendingUp, BookOpen, Users, Star, ArrowRight } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Post, Category } from '../types/database';
import PostCard from '../components/blog/PostCard';

const HomePage: React.FC = () => {
  const [featuredPosts, setFeaturedPosts] = useState<Post[]>([]);
  const [latestPosts, setLatestPosts] = useState<Post[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [stats, setStats] = useState({
    totalPosts: 0,
    totalAuthors: 0,
    totalViews: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Fetch featured posts
      const { data: featured } = await supabase
        .from('posts')
        .select(`
          *,
          profiles (username, full_name, avatar_url),
          categories (id, name, slug, color)
        `)
        .eq('status', 'published')
        .eq('featured', true)
        .order('published_at', { ascending: false })
        .limit(3);

      // Fetch latest posts
      const { data: latest } = await supabase
        .from('posts')
        .select(`
          *,
          profiles (username, full_name, avatar_url),
          categories (id, name, slug, color)
        `)
        .eq('status', 'published')
        .order('published_at', { ascending: false })
        .limit(6);

      // Fetch categories
      const { data: categoriesData } = await supabase
        .from('categories')
        .select('*')
        .order('name');

      // Fetch stats
      const { count: postsCount } = await supabase
        .from('posts')
        .select('id', { count: 'exact' })
        .eq('status', 'published');

      const { count: authorsCount } = await supabase
        .from('profiles')
        .select('id', { count: 'exact' });

      const { data: viewsData } = await supabase
        .from('posts')
        .select('view_count')
        .eq('status', 'published');

      const totalViews = viewsData?.reduce((sum, post) => sum + post.view_count, 0) || 0;

      // Add stats to posts
      const postsWithStats = await Promise.all(
        (latest || []).map(async (post) => {
          const { data: postTags } = await supabase
            .from('post_tags')
            .select('tags (id, name, slug)')
            .eq('post_id', post.id);

          const { count: likesCount } = await supabase
            .from('likes')
            .select('id', { count: 'exact' })
            .eq('post_id', post.id);

          const { count: commentsCount } = await supabase
            .from('comments')
            .select('id', { count: 'exact' })
            .eq('post_id', post.id);

          return {
            ...post,
            tags: postTags?.map(pt => pt.tags).filter(Boolean) || [],
            likes_count: likesCount || 0,
            comments_count: commentsCount || 0,
          };
        })
      );

      const featuredWithStats = await Promise.all(
        (featured || []).map(async (post) => {
          const { data: postTags } = await supabase
            .from('post_tags')
            .select('tags (id, name, slug)')
            .eq('post_id', post.id);

          const { count: likesCount } = await supabase
            .from('likes')
            .select('id', { count: 'exact' })
            .eq('post_id', post.id);

          const { count: commentsCount } = await supabase
            .from('comments')
            .select('id', { count: 'exact' })
            .eq('post_id', post.id);

          return {
            ...post,
            tags: postTags?.map(pt => pt.tags).filter(Boolean) || [],
            likes_count: likesCount || 0,
            comments_count: commentsCount || 0,
          };
        })
      );

      setFeaturedPosts(featuredWithStats);
      setLatestPosts(postsWithStats);
      setCategories(categoriesData || []);
      setStats({
        totalPosts: postsCount || 0,
        totalAuthors: authorsCount || 0,
        totalViews,
      });
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-indigo-600 via-purple-600 to-indigo-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Welcome to <span className="text-yellow-300">BlogSpace</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-indigo-100 max-w-3xl mx-auto">
              Discover amazing stories, insights, and ideas from our community of writers. 
              Share your thoughts and connect with readers worldwide.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/register"
                className="inline-flex items-center px-8 py-3 bg-white text-indigo-600 font-semibold rounded-lg hover:bg-gray-100 transition-colors"
              >
                Start Writing
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
              <Link
                to="/posts"
                className="inline-flex items-center px-8 py-3 border-2 border-white text-white font-semibold rounded-lg hover:bg-white hover:text-indigo-600 transition-colors"
              >
                Explore Posts
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white rounded-lg shadow-lg p-6 text-center">
            <BookOpen className="h-12 w-12 text-indigo-600 mx-auto mb-4" />
            <div className="text-2xl font-bold text-gray-900 mb-1">
              {stats.totalPosts.toLocaleString()}
            </div>
            <div className="text-gray-600">Published Posts</div>
          </div>
          <div className="bg-white rounded-lg shadow-lg p-6 text-center">
            <Users className="h-12 w-12 text-purple-600 mx-auto mb-4" />
            <div className="text-2xl font-bold text-gray-900 mb-1">
              {stats.totalAuthors.toLocaleString()}
            </div>
            <div className="text-gray-600">Writers</div>
          </div>
          <div className="bg-white rounded-lg shadow-lg p-6 text-center">
            <TrendingUp className="h-12 w-12 text-emerald-600 mx-auto mb-4" />
            <div className="text-2xl font-bold text-gray-900 mb-1">
              {stats.totalViews.toLocaleString()}
            </div>
            <div className="text-gray-600">Total Views</div>
          </div>
        </div>
      </div>

      {/* Featured Posts */}
      {featuredPosts.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">
                Featured Posts
              </h2>
              <p className="text-gray-600">
                Handpicked stories from our community
              </p>
            </div>
            <Star className="h-8 w-8 text-yellow-500" />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredPosts.map(post => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        </section>
      )}

      {/* Categories */}
      {categories.length > 0 && (
        <section className="bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Explore Categories
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Discover content that interests you most
              </p>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {categories.map(category => (
                <Link
                  key={category.id}
                  to={`/category/${category.slug}`}
                  className="group p-6 rounded-lg border-2 border-gray-200 hover:border-indigo-300 transition-colors text-center"
                >
                  <div
                    className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center text-white font-bold text-xl group-hover:scale-110 transition-transform"
                    style={{ backgroundColor: category.color }}
                  >
                    {category.name.charAt(0)}
                  </div>
                  <h3 className="font-semibold text-gray-900 group-hover:text-indigo-600 transition-colors">
                    {category.name}
                  </h3>
                  {category.description && (
                    <p className="text-sm text-gray-500 mt-1">
                      {category.description}
                    </p>
                  )}
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Latest Posts */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">
              Latest Posts
            </h2>
            <p className="text-gray-600">
              Fresh content from our writers
            </p>
          </div>
          <Link
            to="/posts"
            className="flex items-center text-indigo-600 hover:text-indigo-800 font-medium transition-colors"
          >
            View all posts
            <ArrowRight className="ml-1 h-4 w-4" />
          </Link>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-white rounded-lg shadow-sm border animate-pulse">
                <div className="aspect-video bg-gray-200 rounded-t-lg"></div>
                <div className="p-6">
                  <div className="h-4 bg-gray-200 rounded w-1/4 mb-3"></div>
                  <div className="h-6 bg-gray-200 rounded w-3/4 mb-3"></div>
                  <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-2/3"></div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {latestPosts.map(post => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        )}
      </section>

      {/* CTA Section */}
      <section className="bg-indigo-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Share Your Story?
          </h2>
          <p className="text-xl text-indigo-100 mb-8 max-w-2xl mx-auto">
            Join our community of writers and readers. Create your account and start publishing today.
          </p>
          <Link
            to="/register"
            className="inline-flex items-center px-8 py-3 bg-white text-indigo-600 font-semibold rounded-lg hover:bg-gray-100 transition-colors"
          >
            Get Started
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;